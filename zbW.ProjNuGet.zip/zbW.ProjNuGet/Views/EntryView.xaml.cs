﻿namespace zbW.ProjNuGet.Views
{
    /// <summary>
    /// Interaktionslogik für LoggingView.xaml
    /// </summary>
    public partial class LoggingView : System.Windows.Controls.UserControl
    {
        public LoggingView()
        {
            InitializeComponent();
        }
    }
}
