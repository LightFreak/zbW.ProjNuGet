﻿namespace zbW.ProjNuGet.Views
{
    /// <summary>
    /// Interaktionslogik für UserControl.xaml
    /// </summary>
    public partial class UserControl : System.Windows.Controls.UserControl
    {
        public UserControl()
        {
            InitializeComponent();
        }
    }
}
