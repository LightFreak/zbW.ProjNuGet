﻿namespace zbW.ProjNuGet.Views
{
    /// <summary>
    /// Interaction logic for LocationView.xaml
    /// </summary>
    public partial class LocationView : System.Windows.Controls.UserControl
    {
        public LocationView()
        {
            InitializeComponent();
        }
    }
}
