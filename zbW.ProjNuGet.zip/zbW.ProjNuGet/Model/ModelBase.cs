﻿using DuplicateCheckerLib;

namespace zbW.ProjNuGet.Model
{
    public abstract class ModelBase : IEntity
    {
        public abstract int Id { get; set; }
    }
}
