Release notes moved to https://github.com/linq2db/linq2db/wiki/Releases-and-Roadmap
